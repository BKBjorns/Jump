<?php
ob_start();
include("header.php");

?>


    <div class="wrapper">
        <!--<img src="img/gradient.jpg" title="Background" />-->

        <div class="logoLogin">
        </div>
        <div class="container">

          <div class="indexBtn">
            <div class="buttondiv">
              <a href="EventOverview.php">Event Overview</a>
            </div>

          </div>

            <div class="indexBtn">
              <div class="buttondiv">
                <a href="login.php">Login</a>
              </div>
            </div>
            <div class="newuserdiv">
              <a href="newuser.php" class="newuser">New User?</a>
            </div>

        </div>

    </div>




<?php
include("footer.php");

?>
