        <footer>
        </footer>
               	<script type="text/javascript" charset="utf-8" src="js/script.js"></script>

    </body>
</html>
