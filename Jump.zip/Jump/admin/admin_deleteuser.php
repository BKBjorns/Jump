<?php 
include("admin_header.php");
include("admin_menu.php");
include("../userinfo.php");


@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

if ($db->connect_error) {
  echo "could not connect: " . $db->connect_error;
  exit();
}

$query="SELECT userID, type, userpass, email, image, school, firstname, lastname, organisation FROM `Users`";
$stmt = $db->prepare($query);
$stmt->bind_result($userID, $type, $userpass, $email, $image, $school, $firstname, $lastname, $organisation);
$stmt->execute();


if(isset($_POST['minus'])){
    
    $userID = $_POST['minus'];
    
    $deleteQuery = "DELETE FROM Users WHERE userID = {$userID}";
//    echo "$deleteQuery";
//    exit();
    $stmt = $db->prepare($deleteQuery);
    $stmt->execute();
    header("location:admin_deleteuser.php");
    
}

?> 
<div class="allUsers">
<?php
while($stmt->fetch()){
    
    if($type == 'student'){?>
       <div class="userContainer">
          
         <div class="student">
             <h3><?php echo "$firstname, $lastname"; ?></h3> 
         </div>
          <form method="POST" action='admin_deleteuser.php'>
                  <input type="submit" value="—" class="plusBtn" name="minus">
                  <input type="hidden" value="<?php echo "$userID"; ?>" name="userID">
              </form>
          <!---------event information & expand btn-->
          <div class="infoContainer">
              <p class="user">
                 <?php echo "<p>User ID: $userID </p> <p>Email: $email </p> <p>School: $school </p>"; ?>
              </p> 
            </div>
        </div> 
    <?php }
    
    else if($type == 'organisation'){?>
       <div class="userContainer">
          
         <div class="organisation">
             <h3><?php echo "$organisation"; ?></h3> 
         </div>
          <form method="POST" action='admin_deleteuser.php'>
                  <input type="submit" value="—" class="plusBtn" name="minus">
                  <input type="hidden" value="<?php echo "$userID"; ?>" name="userID">
              </form>
          <!---------event information & expand btn-->
          <div class="infoContainer">
              <p class="user">
                 <?php echo "<p>User ID: $userID </p> <p>Email: $email </p> <p>School: $school </p>"; ?>
              </p> 
            </div>
        </div> 
    
<?php
    }
}
?>
</div>

<?php 
include("../footer.php");

?>