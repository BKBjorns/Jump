<?php 
include("../config.php");

?>

<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1,width= device-width">
        
        <!-- Google fonts Roboto -------------------------->
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet">
        
        <!-- Font Awesome --------------------------------->
        <script src="https://use.fontawesome.com/18bf7bcf71.js"></script>
        
        <!-- Start: Needed for LESS ----------------------->
		<link rel="stylesheet" type="text/css" href="../css/main.css" />
       <!-- The jquery file----------------->
        <script src="js/jquery.js"></script>
        <title>Jump!</title>
    </head>
    
    <body>

    
 