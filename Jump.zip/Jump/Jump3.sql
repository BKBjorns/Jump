-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 31, 2017 at 06:16 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Jump`
--

-- --------------------------------------------------------

--
-- Table structure for table `Attend`
--

CREATE TABLE IF NOT EXISTS `Attend` (
  `eventID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `nrOfattendens` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Attend`
--

INSERT INTO `Attend` (`eventID`, `userID`, `nrOfattendens`) VALUES
(1, 1, 0),
(2, 1, 0),
(3, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Countries`
--

CREATE TABLE IF NOT EXISTS `Countries` (
  `Location ID` int(11) NOT NULL,
  `Country` int(11) NOT NULL,
  `City` int(11) NOT NULL,
  `Adress` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Events`
--

CREATE TABLE IF NOT EXISTS `Events` (
  `eventID` int(11) NOT NULL,
  `title` char(255) NOT NULL,
  `description` char(255) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` int(11) NOT NULL,
  `time` time NOT NULL,
  `price` int(11) NOT NULL,
  `location` char(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` char(255) NOT NULL,
  `host` char(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Events`
--

INSERT INTO `Events` (`eventID`, `title`, `description`, `startdate`, `enddate`, `time`, `price`, `location`, `image`, `link`, `host`) VALUES
(1, 'Waffle Night', '........', '2011-12-17', 10, '00:00:00', 0, '', 'hint.jpg', '', ''),
(2, 'rwevgeb', 'eBG Description', '2017-10-15', 0, '01:59:00', 0, 'Event Location', 'user.jpg', '', ''),
(3, 'Hint on the Run', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi a quam tristique, faucibus libero congue, viverra tellus. Sed lectus nibh, vehicula sed metus consectetur, interdum ultricies odio. Phasellus eu nibh ut quam aliquet maximus sed sit amet enim.', '2017-10-14', 0, '23:00:00', 0, 'JTH Entrance', 'wafflenight.jpg', '', ''),
(17, 'Jump Presentation', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi a quam tristique, faucibus libero congue, viverra tellus. Sed lectus nibh, vehicula sed metus consectetur, interdum ultricies odio. Phasellus eu nibh ut quam aliquet maximus sed sit amet enim.', '2017-11-11', 0, '11:00:00', 0, 'JTH', 'logo.final-01.png', '', ''),
(18, 'New Event', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi a quam tristique, faucibus libero congue, viverra tellus. Sed lectus nibh, vehicula sed metus consectetur, interdum ultricies odio. Phasellus eu nibh ut quam aliquet maximus sed sit amet enim.', '2017-11-19', 0, '12:12:00', 0, 'RIO', '', '', ''),
(19, 'Event Title', 'Event Description', '2017-10-07', 0, '22:45:00', 0, 'Event Location', '', '', ''),
(20, 'New Event', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi a quam tristique, faucibus libero congue, viverra tellus. Sed lectus nibh, vehicula sed metus consectetur, interdum ultricies odio. Phasellus eu nibh ut quam aliquet maximus sed sit amet enim.', '2017-10-13', 0, '12:12:00', 0, 'HÃ¤lso Park', '', '', ''),
(21, 'BBQ HÃ¤lso', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi a quam tristique, faucibus libero congue, viverra tellus. Sed lectus nibh, vehicula sed metus consectetur, interdum ultricies odio. Phasellus eu nibh ut quam aliquet maximus sed sit amet enim.', '2017-10-07', 0, '12:12:00', 0, 'HÃ¤lso', '', '', ''),
(22, 'New event', 'upload', '2017-11-12', 0, '23:34:00', 0, 'HLK', '', '', ''),
(23, 'Event Title', 'Event Description', '2017-10-27', 0, '23:07:00', 0, 'NEW', 'img.png', '', ''),
(24, 'Event Title', 'Event Description', '2017-10-27', 0, '23:07:00', 0, 'NEW', '', '', ''),
(25, 'Event Title', 'Event Description', '2017-10-27', 0, '23:07:00', 0, 'NEW', '', '', ''),
(26, 'Event Title', 'Event Description', '2017-10-27', 0, '23:07:00', 0, 'NEW', '', '', ''),
(27, 'Event Title', 'Event Description', '2017-10-22', 0, '03:45:00', 0, 'Event Location', '', '', ''),
(28, 'Event Title', 'Event Description', '0000-00-00', 0, '00:00:00', 0, '', '7e8d2866fcb13b1ac425b6b8029dc9bd.jpg', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `Schools`
--

CREATE TABLE IF NOT EXISTS `Schools` (
  `School ID` int(11) NOT NULL,
  `School Name` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Schools`
--

INSERT INTO `Schools` (`School ID`, `School Name`) VALUES
(1, 'JTH'),
(2, 'HLK'),
(3, 'JIBS'),
(4, 'HÄLSO'),
(5, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE IF NOT EXISTS `Users` (
  `userID` int(11) NOT NULL,
  `type` varchar(13) NOT NULL,
  `userpass` char(255) NOT NULL,
  `email` char(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `school` varchar(50) NOT NULL,
  `firstname` char(255) NOT NULL,
  `lastname` char(255) NOT NULL,
  `organisation` char(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`userID`, `type`, `userpass`, `email`, `image`, `school`, `firstname`, `lastname`, `organisation`) VALUES
(1, '0', '271e9a568c0e9e562431ccb1f5da3422162de7b8', 'jump@mail.com', 'logo.png', '0', 'Jump', '', ''),
(20, '0', '8be3c943b1609fffbfc51aad666d0a04adf83c9d', 'one@mail.se', 'gradient.jpg', '0', 'one', 'ONE', ''),
(31, '0', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'Email@mail.com', '', '0', 'First name', 'Last name', ''),
(33, '0', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'Email@jump.com', '', 'JIBS', 'Hoppa', 'Last name', ''),
(35, '0', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'Email@hh.com', '', 'JIBS', 'upp', 'Last name', ''),
(36, 'student', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'Email@ll', '', 'HLK', 'upp igen', 'Last name', '');

-- --------------------------------------------------------

--
-- Table structure for table `User Type`
--

CREATE TABLE IF NOT EXISTS `User Type` (
  `Type ID` int(11) NOT NULL,
  `Type` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User Type`
--

INSERT INTO `User Type` (`Type ID`, `Type`) VALUES
(1, 'Admin'),
(2, 'Student'),
(3, 'Organisation');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Countries`
--
ALTER TABLE `Countries`
  ADD PRIMARY KEY (`Location ID`);

--
-- Indexes for table `Events`
--
ALTER TABLE `Events`
  ADD PRIMARY KEY (`eventID`);

--
-- Indexes for table `Schools`
--
ALTER TABLE `Schools`
  ADD PRIMARY KEY (`School ID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `User Type`
--
ALTER TABLE `User Type`
  ADD PRIMARY KEY (`Type ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Events`
--
ALTER TABLE `Events`
  MODIFY `eventID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
